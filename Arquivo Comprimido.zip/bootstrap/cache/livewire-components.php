<?php return array (
  'category-create' => 'App\\Http\\Livewire\\CategoryCreate',
  'ckeditor' => 'App\\Http\\Livewire\\Ckeditor',
  'form-checkbox-element' => 'App\\Http\\Livewire\\FormCheckboxElement',
  'service-create' => 'App\\Http\\Livewire\\ServiceCreate',
);