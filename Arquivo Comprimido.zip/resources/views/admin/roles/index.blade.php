@extends('admin.layouts.app')
@section('title' , Regras )

@section('content')


@endsection
