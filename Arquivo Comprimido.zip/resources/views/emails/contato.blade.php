<h2>Hey, Você recebeu um contato de {{ $data->name }}</h2>
<br>

<strong>Detalhes: </strong><br>
<strong>Nome: </strong>{{ $data->name }} <br>
<strong>Email: </strong>{{ $data->email }} <br>
<strong>Telefone/Whatsapp: </strong>{{ $data->whatsapp }} <br>
<strong>Assunto: </strong>{{ $data->subject }} <br>
<strong>Mensagem: </strong>{{ $data->message }} <br><br>

Obrigado
