@include('site.layout.header')

@yield('content')


  <!-- ======= Footer ======= -->
  @include('site.layout.footer')
