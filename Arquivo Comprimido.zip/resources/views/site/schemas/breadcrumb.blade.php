<script type="application/ld+json">
    {
      "@context": "https://schema.org/",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "nome da pagina",
        "item": "url da pagina"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "pagina 2",
        "item": "urlpagina2"
      }]
    }
    </script>
