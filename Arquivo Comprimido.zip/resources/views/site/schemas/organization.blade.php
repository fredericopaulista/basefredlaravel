<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "nomedaempresa",
      "url": "urldosite",
      "logo": "logo",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "telefone",
        "contactType": "customer service",
        "contactOption": "TollFree",
        "areaServed": "BR",
        "availableLanguage": "Portuguese"
      },
      "sameAs": [
        "urlfacebook",
        "urltwitter",
        "urlinstagram",
        "urlyoutube",
        "urllinkedin"
      ]
    }
    </script>
